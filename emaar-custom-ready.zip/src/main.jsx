import React from "react";
import ReactDOM from "react-dom/client";
import InvestmentApp from "./InvestmentApp";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <InvestmentApp />
  </React.StrictMode>
);
