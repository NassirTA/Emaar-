export const APP_NAME = "EMAAR PROPERTY'S LTD.";
export const BASE_DOMAIN = "https://www.emaarbd.com"; // custom domain placeholder
export const ADMIN_EMAIL = "admin@emaar.com";
export const ADMIN_SECRET = "/* Admin password will be hashed in production */";
