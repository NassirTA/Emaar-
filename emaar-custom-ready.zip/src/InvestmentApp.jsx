import { APP_NAME, BASE_DOMAIN } from "./config/appConfig";

export default function InvestmentApp() {
  return (
    <div style={{ padding: 30, textAlign: "center" }}>
      <img src="./assets/logo.png" alt="Logo" width={100} />
      <h1>{APP_NAME}</h1>
      <p>This app will be served on: {BASE_DOMAIN}</p>
      <p>All investment features included.</p>
    </div>
  );
}
